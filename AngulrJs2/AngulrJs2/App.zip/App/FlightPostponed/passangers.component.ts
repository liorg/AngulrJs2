﻿import { Component } from '@angular/core';
@Component({
    selector: 'pm-passangers',
    templateUrl: 'app/FlightPostponed/passangers.component.html',
    styleUrls: ['app/FlightPostponed/passangers.component.css']
})
export class PassangersComponent  {
   // debugger;
    PassangersTitle: string = 'aa !!!';
}
